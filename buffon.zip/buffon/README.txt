This is the buffon bot code. This is a ros project.
in order to setup the project run the setup.sh file.
