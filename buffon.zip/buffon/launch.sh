#!/bin/bash

roslaunch openni_launch openni.launch
